import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.Arrays;
import java.util.Base64;

/**
 * Implementación de la interfaz AlgoritmoCifrado utilizando el estándar AES.
 * Se encarga de cifrar y descifrar las contraseñas de los usuarios.
 *
 * ADVERTENCIA: Esta implementación utiliza una clave "quemada" (hardcoded)
 * derivada de una constante, lo cual NO es una práctica segura para
 * entornos de producción, pero es funcional para un proyecto académico.
 */
public class CifradoAES implements AlgoritmoCifrado { //

    private static final String ALGORITMO = "AES";

    // NUNCA uses una clave predecible o simple en una app real.
    private static final String CLAVE_SECRETA_STRING = "MazeHunter-2025-Proyecto-PA";

    private SecretKeySpec secretKey;

    /**
     * Constructor que prepara la clave secreta para el cifrado.
     * La clave secreta debe tener un tamaño específico (16, 24 o 32 bytes).
     * Aquí usamos SHA-256 para "hashear" nuestra clave de string
     * y tomar los primeros 16 bytes (128 bits) para AES.
     */
    public CifradoAES() {
        try {
            byte[] keyBytes = CLAVE_SECRETA_STRING.getBytes(StandardCharsets.UTF_8);
            MessageDigest sha = MessageDigest.getInstance("SHA-256");
            keyBytes = sha.digest(keyBytes);

            // Usamos solo los primeros 16 bytes (128 bits) para AES-128
            keyBytes = Arrays.copyOf(keyBytes, 16);

            this.secretKey = new SecretKeySpec(keyBytes, ALGORITMO);

        } catch (NoSuchAlgorithmException e) {
            // Esta excepción no debería ocurrir si SHA-256 está disponible
            throw new RuntimeException("Error al inicializar el cifrador: " + e.getMessage());
        }
    }

    /**
     * Cifra un texto plano (contraseña) y lo devuelve como un string Base64.
     * @param textoPlano El texto a cifrar.
     * @return El texto cifrado, codificado en Base64, o null si falla.
     */
    @Override
    public String cifrar(String textoPlano) { //
        if (textoPlano == null || textoPlano.isEmpty()) {
            return null;
        }

        try {
            // 1. Obtener una instancia del cifrador AES
            Cipher cipher = Cipher.getInstance(ALGORITMO);

            // 2. Inicializar el cifrador en modo ENCRYPT (cifrar)
            cipher.init(Cipher.ENCRYPT_MODE, this.secretKey);

            // 3. Cifrar el texto
            byte[] bytesCifrados = cipher.doFinal(textoPlano.getBytes(StandardCharsets.UTF_8));

            // 4. Codificar los bytes cifrados (que no son un string legible) a Base64
            // para poder guardarlos fácilmente en el JSON.
            return Base64.getEncoder().encodeToString(bytesCifrados);

        } catch (Exception e) {
            System.err.println("Error al cifrar: " + e.getMessage());
            return null;
        }
    }

    /**
     * Descifra un texto cifrado (en Base64) y lo devuelve como texto plano.
     * @param textoCifrado El texto a descifrar (debe estar en formato Base64).
     * @return El texto plano (contraseña), o null si falla.
     */
    @Override
    public String descifrar(String textoCifrado) { //
        if (textoCifrado == null || textoCifrado.isEmpty()) {
            return null;
        }

        try {
            // 1. Obtener una instancia del cifrador AES
            Cipher cipher = Cipher.getInstance(ALGORITMO);

            // 2. Inicializar el cifrador en modo DECRYPT (descifrar)
            cipher.init(Cipher.DECRYPT_MODE, this.secretKey);

            // 3. Decodificar de Base64 (para obtener los bytes cifrados originales)
            byte[] bytesDecodificados = Base64.getDecoder().decode(textoCifrado);

            // 4. Descifrar los bytes
            byte[] bytesDescifrados = cipher.doFinal(bytesDecodificados);

            // 5. Convertir los bytes descifrados de vuelta a un String
            return new String(bytesDescifrados, StandardCharsets.UTF_8);

        } catch (Exception e) {
            // Esto puede fallar si la clave es incorrecta o los datos están corruptos
            System.err.println("Error al descifrar (¿clave incorrecta o datos corruptos?): " + e.getMessage());
            return null;
        }
    }
}
