import java.util.Scanner;

/**
 * Clase central del juego (el "motor").
 * Controla el bucle principal, el estado de la partida,
 * el movimiento del jugador y las interacciones con el laberinto.
 */
public class Juego {
    private Laberinto laberinto;          //
    private Jugador jugador;              //
    private final GestorPersistencia gestorPersistencia; //
    private final GestorEstadisticas gestorEstadisticas; //
    private Usuario usuarioActual;        //
    private boolean enPartida;            //
    private long tiempoInicio;            // (Marca de tiempo de cuándo empezó/cargó)

    /**
     * Constructor que inicializa el motor del juego con sus dependencias.
     * @param gp Gestor para guardar/cargar partidas.
     * @param ge Gestor para guardar estadísticas.
     */
    public Juego(GestorPersistencia gp, GestorEstadisticas ge) { //
        this.gestorPersistencia = gp;
        this.gestorEstadisticas = ge;
        this.enPartida = false;
    }

    /**
     * Inicia una partida nueva desde cero.
     * @param usuario El usuario que está jugando.
     * @param filas Dimensiones del laberinto.
     * @param columnas Dimensiones del laberinto.
     */
    public void iniciarPartidaNueva(Usuario usuario, int filas, int columnas) { //
        System.out.println("Generando nuevo laberinto... 🌀");
        this.laberinto = new Laberinto(filas, columnas); //
        this.jugador = new Jugador(laberinto.getPosicionInicio());
        this.usuarioActual = usuario;
        this.enPartida = true;
        this.tiempoInicio = System.currentTimeMillis(); //

        System.out.println("¡Partida iniciada! Usa W, A, S, D para moverte.");
        bucleDeJuego(); //
    }

    /**
     * Carga una partida guardada previamente por el usuario.
     * @param usuario El usuario que desea cargar su partida.
     */
    public void cargarPartida(Usuario usuario) { //
        EstadoJuego estadoGuardado = gestorPersistencia.cargarPartidaGuardada(usuario); //

        if (estadoGuardado != null) {
            this.laberinto = estadoGuardado.getLaberinto();
            this.jugador = estadoGuardado.getJugador();
            this.usuarioActual = usuario;
            this.enPartida = true;

            // Ajustamos el tiempo de inicio para que el cronómetro continúe
            long tiempoYaJugado = estadoGuardado.getTiempoTranscurridoParcialMs();
            this.tiempoInicio = System.currentTimeMillis() - tiempoYaJugado;

            System.out.println("¡Partida cargada exitosamente! Continuas donde lo dejaste.");
            bucleDeJuego(); //
        } else {
            System.out.println("No se encontró ninguna partida guardada para " + usuario.getCorreo());
        }
    }

    /**
     * Bucle principal del juego. Captura la entrada del usuario,
     * procesa el movimiento y actualiza el estado del juego.
     */
    private void bucleDeJuego() { //
        // NOTA: Idealmente, el Scanner se pasaría desde MenuPrincipal,
        // pero para seguir el diagrama, creamos uno local.
        Scanner scanner = new Scanner(System.in);

        while (this.enPartida) {
            dibujarTablero(); //

            // Mostrar HUD (Heads-Up Display)
            System.out.println("Vida: " + jugador.getVida() + "%  | Llave: "
                    + (jugador.tieneLlave() ? "Sí " : "No "));
            System.out.print("Mover (W/A/S/D) | Salir (Q): ");

            String input = scanner.nextLine().toUpperCase();
            if (input.isEmpty()) continue;

            char mov = input.charAt(0);

            if (mov == 'Q') { //
                terminarJuego(false, "Partida abandonada.");
                break; // Sale del bucle
            }

            if ("WASD".indexOf(mov) != -1) {
                procesarMovimiento(mov); //

                // Guardar después de CADA movimiento
                guardarPartidaActual();
            } else {
                System.out.println("Comando no válido. Usa W, A, S, D o Q.");
            }

            // Comprobar condiciones de fin de juego DESPUÉS del movimiento
            if (jugador.getVida() <= 0) {
                dibujarTablero(); // Mostrar el estado final (muerto)
                terminarJuego(false, "¡Has muerto! 💀 Fin del juego.");
                break;
            }

            // verificarCondicionVictoria se llama dentro de procesarMovimiento
            // (específicamente en interactuarConCelda)
        }
    }

    /**
     * Dibuja el estado actual del laberinto y el jugador en la consola.
     */
    private void dibujarTablero() { //
        // Limpiar la consola (funciona en la mayoría de terminales)
        System.out.print("\033[H\033[2J");
        System.out.flush();

        System.out.println("--- 🏺 MAZE HUNTER 🏺 ---");
        Coordenada posJugador = jugador.getPosicion();

        for (int i = 0; i < laberinto.getFilas(); i++) {
            for (int j = 0; j < laberinto.getColumnas(); j++) {
                if (i == posJugador.x() && j == posJugador.y()) {
                    // Requisito: Jugador se muestra como '@'
                    System.out.print('@' + " ");
                } else {
                    Celda celda = laberinto.getCelda(i, j);
                    // Usa el caracter definido en el Enum TipoCelda
                    System.out.print(celda.getTipo().getCaracter() + " ");
                }
            }
            System.out.println(); // Siguiente fila
        }
        System.out.println("---------------------------");
    }

    /**
     * Procesa la entrada de movimiento del jugador (W, A, S, D).
     * @param mov El carácter de movimiento.
     */
    private void procesarMovimiento(char mov) { //
        Coordenada posActual = jugador.getPosicion();
        int deltaX = 0, deltaY = 0;

        //
        switch (mov) {
            case 'W': deltaX = -1; break; // Arriba
            case 'A': deltaY = -1; break; // Izquierda
            case 'S': deltaX = 1;  break; // Abajo
            case 'D': deltaY = 1;  break; // Derecha
        }

        int nuevaX = posActual.x() + deltaX;
        int nuevaY = posActual.y() + deltaY;

        // 1. Validar límites del laberinto
        if (!laberinto.esPosicionValida(nuevaX, nuevaY)) {
            System.out.println("¡Auch! Chocaste con el borde del mundo.");
            return;
        }

        Celda celdaDestino = laberinto.getCelda(nuevaX, nuevaY);

        // 2. Validar si la celda es transitable
        if (!celdaDestino.esTransitable()) {
            System.out.println("¡Es un muro! 🧱 No puedes pasar.");
            return; //
        }

        // 3. Mover al jugador
        jugador.mover(deltaX, deltaY); //

        // 4. Interactuar con la celda a la que se movió
        interactuarConCelda(celdaDestino); //
    }

    /**
     * Maneja la lógica de lo que sucede cuando un jugador entra en una celda.
     * @param celda La celda en la que el jugador acaba de entrar.
     */
    private void interactuarConCelda(Celda celda) { //
        TipoCelda tipo = celda.getTipo();

        // Evitar que los objetos se activen múltiples veces
        if (celda.fueVisitada()) {
            // Si es la META, siempre debe verificar la victoria
            if (tipo == TipoCelda.META) {
                verificarCondicionVictoria(); //
            }
            return; // Ya interactuó con esta celda
        }

        switch (tipo) {
            case TRAMPA: //
                int dano = Jugador.VIDA_MAXIMA / 10; // 10% de la vida MÁXIMA
                jugador.recibirDano(dano); //
                jugador.activarTrampa(); //
                System.out.println("¡Caíste en una trampa! 💀 Pierdes " + dano + "% de vida.");
                celda.setFueVisitada(true); // La trampa solo se activa una vez
                break;

            case LLAVE: //
                jugador.recolectarLlave(); //
                System.out.println("¡Encontraste la Llave! Ahora puedes abrir la salida.");
                celda.setTipo(TipoCelda.CAMINO); // La llave desaparece
                celda.setFueVisitada(true);
                break;

            case ENERGIA:
                int energiaGanada = 10; // Valor de ejemplo
                jugador.recolectarEnergia(energiaGanada); //
                System.out.println("¡Cristal de energía! ⚡ Ganas " + energiaGanada + " puntos.");
                celda.setTipo(TipoCelda.CAMINO); // El cristal desaparece
                celda.setFueVisitada(true);
                break;

            case VIDA_EXTRA: //
                int cura = 20; // Valor de ejemplo
                jugador.curar(cura); //
                System.out.println("¡Botiquín! Recuperas " + cura + "% de vida.");
                celda.setTipo(TipoCelda.CAMINO); // El botiquín desaparece
                celda.setFueVisitada(true);
                break;

            case META: //
                celda.setFueVisitada(true); // Marca la meta como visitada
                verificarCondicionVictoria(); //
                break;

            case CAMINO: //
                // No pasa nada, solo se mueve.
                break;

            default:
                break;
        }
    }

    /**
     * Comprueba si el jugador ha cumplido las condiciones para ganar.
     * Se llama cuando el jugador entra en la celda META.
     */
    private void verificarCondicionVictoria() { //
        // Esta comprobación solo se activa si el jugador está en la meta
        Coordenada pos = jugador.getPosicion();
        if (laberinto.getCelda(pos.x(), pos.y()).getTipo() != TipoCelda.META) {
            return;
        }

        // Requisito: Debe tener la llave para ganar
        if (jugador.tieneLlave()) {
            dibujarTablero(); // Mostrar el tablero final
            terminarJuego(true, "¡Felicidades! ¡Encontraste la salida con la llave! 🏆");
        } else {
            System.out.println("¡Es la salida! 🚪 Pero... necesitas la llave 🗝️ para abrirla.");
        }
    }

    /**
     * Finaliza la partida, actualiza el estado y guarda las estadísticas.
     * @param gano true si el jugador ganó, false si perdió o abandonó.
     * @param mensaje El mensaje de fin de juego a mostrar.
     */
    public void terminarJuego(boolean gano, String mensaje) { //
        if (!this.enPartida) return; // Evitar que se llame múltiples veces

        this.enPartida = false;
        long tiempoTranscurrido = System.currentTimeMillis() - this.tiempoInicio;

        System.out.println("\n" + mensaje);
        System.out.println("--- Fin de la Partida ---");

        // Mostrar estadísticas finales
        long minutos = (tiempoTranscurrido / (1000 * 60)) % 60;
        long segundos = (tiempoTranscurrido / 1000) % 60;
        System.out.printf("Duración: %02d:%02d\n", minutos, segundos); //
        System.out.println("Cristales: " + jugador.getCristalesRecolectados()); //
        System.out.println("Trampas activadas: " + jugador.getTrampasActivadas()); //
        System.out.println("Vida restante: " + jugador.getVida() + "%%"); //

        // Crear y guardar la estadística
        Estadistica est = new Estadistica(usuarioActual.getCorreo(), tiempoTranscurrido, laberinto.getFilas(), laberinto.getColumnas(), jugador.getTrampasActivadas(), jugador.getVida(), gano);
        gestorEstadisticas.guardarEstadisticaPartida(est);

        // Limpiar la partida guardada (guardando un estado nulo)
        gestorPersistencia.guardarPartidaActual(null, usuarioActual);
    }

    /**
     * Guarda el estado actual de la partida en curso.
     * Se llama después de cada movimiento.
     */
    public void guardarPartidaActual() {
        if (!this.enPartida) {
            return;
        }

        long tiempoTranscurridoParcial = System.currentTimeMillis() - this.tiempoInicio;

        EstadoJuego estadoActual = new EstadoJuego(
                this.laberinto,
                this.jugador,
                tiempoTranscurridoParcial
        );

        gestorPersistencia.guardarPartidaActual(estadoActual, this.usuarioActual);

    }
}