public enum TipoCelda {
    MURO('#', false),
    CAMINO('.', true),
    META('X', true),
    TRAMPA('T', true),
    LLAVE('K', true),
    ENERGIA('E', true),
    VIDA_EXTRA('+', true),
    JUGADOR('S', true);

    private final char caracter;    //
    private final boolean esTransitable; //

    TipoCelda(char caracter, boolean esTransitable) {
        this.caracter = caracter;
        this.esTransitable = esTransitable;
    }

    public char getCaracter() { //
        return caracter;
    }

    public boolean esTransitable() { //
        return esTransitable;
    }
}
