// Archivo: Jugador.java
public class Jugador {
    public static final int VIDA_MAXIMA = 100; //
    private int vida;                     //
    private boolean tieneLlave;           //
    private int posX;                     //
    private int posY;                     //
    private int trampasActivadas;         //
    private int energiaRecolectada;       //

    public Jugador(Coordenada posicionInicial) { //
        this.vida = VIDA_MAXIMA;
        this.tieneLlave = false;
        this.posX = posicionInicial.x();
        this.posY = posicionInicial.y();
        this.trampasActivadas = 0;
        this.energiaRecolectada = 0;
    }

    public void mover(int deltaX, int deltaY) { //
        this.posX += deltaX;
        this.posY += deltaY;
    }

    public boolean recibirDano(int cantidad) { //
        this.vida -= cantidad;
        if (this.vida <= 0) {
            this.vida = 0;
            return false; // El jugador ha muerto
        }
        return true;
    }

    public void curar(int cantidad) { //
        this.vida += cantidad;
        // La vida no puede superar el 100%
        if (this.vida > VIDA_MAXIMA) {
            this.vida = VIDA_MAXIMA;
        }
    }

    public void recolectarLlave() { //
        this.tieneLlave = true;
    }

    public void recolectarEnergia(int cantidad) { //
        this.energiaRecolectada += cantidad;
    }

    public void activarTrampa() { //
        this.trampasActivadas++;
    }

    public Coordenada getPosicion() { //
        return new Coordenada(posX, posY);
    }

    public int getVida() { return vida; }
    public boolean tieneLlave() { return tieneLlave; }
    public int getTrampasActivadas() { return trampasActivadas; }
    public int getEnergiaRecolectada() { return energiaRecolectada; }
}
