import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.reflect.TypeToken;
import java.io.*;
import java.lang.reflect.Type;
import java.util.List;
import java.util.Map;
import java.util.ArrayList;
import java.util.HashMap;

/**
 * Gestiona toda la lectura y escritura de archivos JSON.
 * Es la única clase que interactúa directamente con el sistema de archivos
 * para la persistencia de datos del juego.
 */
public class GestorPersistencia {

    private final Gson gson; //
    private final String RUTA_USUARIOS = "usuarios.json";     //
    private final String RUTA_PARTIDA_PREFIX = "partida_";    // (Prefijo)
    private final String RUTA_ESTADISTICAS = "estadisticas.json"; //

    /**
     * Constructor. Inicializa la instancia de GSON.
     * Usamos GsonBuilder para "pretty printing", lo que hace
     * que los archivos JSON sean legibles por humanos (ideal para depurar).
     */
    public GestorPersistencia() {
        this.gson = new GsonBuilder()
                .setPrettyPrinting() // Formatea el JSON
                .create();
    }

    // --- MÉTODOS DE USUARIOS ---

    /**
     * Guarda el mapa completo de usuarios en usuarios.json.
     * @param usuarios El mapa de <Correo, Usuario> a guardar.
     */
    public void guardarUsuarios(Map<String, Usuario> usuarios) { //
        String json = gson.toJson(usuarios);
        escribirArchivo(json, RUTA_USUARIOS);
    }

    /**
     * Carga el mapa de usuarios desde usuarios.json.
     * @return Un mapa con los usuarios. Si el archivo no existe,
     * devuelve un mapa vacío.
     */
    public Map<String, Usuario> cargarUsuarios() { //
        String json = leerArchivo(RUTA_USUARIOS);
        if (json == null || json.isEmpty()) {
            return new HashMap<>(); // Devuelve mapa vacío si no hay archivo
        }

        // Se necesita TypeToken para deserializar tipos genéricos como Map<>
        Type tipoMapa = new TypeToken<Map<String, Usuario>>() {}.getType();
        Map<String, Usuario> usuarios = gson.fromJson(json, tipoMapa);

        return (usuarios != null) ? usuarios : new HashMap<>();
    }

    // --- MÉTODOS DE PARTIDA GUARDADA (POR USUARIO) ---

    /**
     * Guarda el estado actual de la partida para un usuario específico.
     * Si el estadoJuego es null, borra el archivo de guardado (al terminar partida).
     * @param estadoJuego El estado del juego a guardar.
     * @param usuario El usuario dueño de esta partida.
     */
    public void guardarPartidaActual(EstadoJuego estadoJuego, Usuario usuario) { //
        if (usuario == null) return;

        String rutaArchivo = RUTA_PARTIDA_PREFIX + usuario.getCorreo() + ".json";

        // Requisito : Guardar partida
        if (estadoJuego != null) {
            String json = gson.toJson(estadoJuego);
            escribirArchivo(json, rutaArchivo);
        } else {
            // Si el estado es null, significa que la partida terminó y debe borrarse
            File archivo = new File(rutaArchivo);
            if (archivo.exists()) {
                archivo.delete();
            }
        }
    }

    /**
     * Carga el estado de una partida guardada para un usuario específico.
     * @param usuario El usuario que desea cargar su partida.
     * @return El EstadoJuego guardado, o null si no se encontró archivo.
     */
    public EstadoJuego cargarPartidaGuardada(Usuario usuario) { //
        if (usuario == null) return null;

        String rutaArchivo = RUTA_PARTIDA_PREFIX + usuario.getCorreo() + ".json";
        String json = leerArchivo(rutaArchivo);

        if (json == null || json.isEmpty()) {
            return null; // No hay partida guardada
        }

        return gson.fromJson(json, EstadoJuego.class);
    }

    // --- MÉTODOS DE ESTADÍSTICAS ---

    /**
     * Guarda la lista completa de estadísticas en estadisticas.json.
     * @param estadisticas La lista de todas las estadísticas.
     */
    public void guardarEstadisticas(List<Estadistica> estadisticas) { //
        String json = gson.toJson(estadisticas);
        escribirArchivo(json, RUTA_ESTADISTICAS);
    }

    /**
     * Carga la lista de estadísticas desde estadisticas.json.
     * @return Una lista con las estadísticas. Si el archivo no existe,
     * devuelve una lista vacía.
     */
    public List<Estadistica> cargarEstadisticas() { //
        String json = leerArchivo(RUTA_ESTADISTICAS);
        if (json == null || json.isEmpty()) {
            return new ArrayList<>(); // Devuelve lista vacía si no hay archivo
        }

        // Se necesita TypeToken para deserializar tipos genéricos como List<>
        Type tipoLista = new TypeToken<List<Estadistica>>() {}.getType();
        List<Estadistica> estadisticas = gson.fromJson(json, tipoLista);

        return (estadisticas != null) ? estadisticas : new ArrayList<>();
    }

    // --- MÉTODOS PRIVADOS DE AYUDA (HELPER) ---

    /**
     * Escribe un contenido de String a un archivo en disco.
     * Utiliza try-with-resources para manejar el FileWriter.
     * @param contenidoJson El string JSON a escribir.
     * @param rutaArchivo El nombre del archivo (ej. "usuarios.json").
     */
    private void escribirArchivo(String contenidoJson, String rutaArchivo) {
        try (FileWriter writer = new FileWriter(rutaArchivo)) {
            writer.write(contenidoJson);
        } catch (IOException e) {
            System.err.println("Error fatal al escribir en " + rutaArchivo + ": " + e.getMessage());
            e.printStackTrace();
        }
    }

    /**
     * Lee el contenido completo de un archivo de texto.
     * Utiliza try-with-resources para manejar el FileReader/BufferedReader.
     * @param rutaArchivo El nombre del archivo a leer.
     * @return El contenido del archivo como String, o null si no se encuentra.
     */
    private String leerArchivo(String rutaArchivo) {
        StringBuilder contenido = new StringBuilder();
        File archivo = new File(rutaArchivo);

        if (!archivo.exists()) {
            return null; // No es un error, el archivo simplemente no existe aún
        }

        try (BufferedReader reader = new BufferedReader(new FileReader(archivo))) {
            String linea;
            while ((linea = reader.readLine()) != null) {
                contenido.append(linea).append("\n");
            }
        } catch (IOException e) {
            System.err.println("Error fatal al leer " + rutaArchivo + ": " + e.getMessage());
            e.printStackTrace();
            return null;
        }

        return contenido.toString();
    }
}