import java.util.Map;
import java.util.HashMap;

public class GestorUsuarios {
    private Map<String, Usuario> usuarios;
    private final GestorPersistencia persistencia;
    private final AlgoritmoCifrado cifrador;

    public GestorUsuarios(GestorPersistencia p, AlgoritmoCifrado c) {
        this.persistencia = p;
        this.cifrador = c;
        this.usuarios = new HashMap<>();
        cargarUsuarios();
    }

    public void cargarUsuarios() {
        Map<String, Usuario> cargados = persistencia.cargarUsuarios();
        if (cargados != null) {
            this.usuarios = cargados;
        }
    }

    private void guardarUsuarios() {
        persistencia.guardarUsuarios(usuarios);
    }

    public boolean registrarUsuario(String correo, String contrasena, String contrasenaRepetida) {
        // TODO: Validar requisitos de contraseña y correo

        if (!contrasena.equals(contrasenaRepetida)) { //
            System.out.println("Error: Las contraseñas no coinciden.");
            return false;
        }
        if (usuarios.containsKey(correo)) { //
            System.out.println("Error: El correo ya está registrado.");
            return false;
        }

        String contrasenaCifrada = cifrador.cifrar(contrasena); //
        Usuario nuevoUsuario = new Usuario(correo, contrasenaCifrada);
        usuarios.put(correo, nuevoUsuario);
        guardarUsuarios();
        System.out.println("Usuario registrado exitosamente.");
        return true;
    }

    public Usuario autenticarUsuario(String correo, String contrasena) { //
        Usuario usuario = usuarios.get(correo);
        if (usuario != null) {
            // Usa el método verificarContrasena del usuario
            if (usuario.verificarContrasena(contrasena, cifrador)) {
                return usuario;
            }
        }
        return null; // Autenticación fallida
    }

    public String recuperarContrasena(String correo) { //
        Usuario usuario = usuarios.get(correo);
        if (usuario != null) {
            // Descrifra y muestra la contraseña
            return cifrador.descifrar(usuario.getContrasenaCifrada());
        }
        return "Error: Correo no encontrado.";
    }
}