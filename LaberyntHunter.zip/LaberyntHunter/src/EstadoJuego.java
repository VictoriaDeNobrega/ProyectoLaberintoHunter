/**
 * Representa el estado guardable de una partida en curso.
 * Esta clase es utilizada por GestorPersistencia para serializar/deserializar
 * el progreso del jugador a un archivo JSON.
 */
public class EstadoJuego {
    private final Laberinto laberinto;
    private final Jugador jugador;
    private final long tiempoTranscurridoParcialMs; // Tiempo jugado hasta el momento de guardar

    public EstadoJuego(Laberinto laberinto, Jugador jugador, long tiempoTranscurridoParcialMs) {
        this.laberinto = laberinto;
        this.jugador = jugador;
        this.tiempoTranscurridoParcialMs = tiempoTranscurridoParcialMs;
    }

    public Laberinto getLaberinto() {
        return laberinto;
    }

    public Jugador getJugador() {
        return jugador;
    }

    public long getTiempoTranscurridoParcialMs() {
        return tiempoTranscurridoParcialMs;
    }
}