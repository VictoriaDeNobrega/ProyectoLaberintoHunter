import java.util.List;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Random;
import java.util.Stack;

/**
 * Representa el laberinto del juego.
 * Se encarga de la generación procedural de la matriz de celdas y
 * de la colocación de los objetos especiales (Meta, Llave, Trampas, etc.).
 */
public class Laberinto {

    private final Celda[][] celdas;           // Matriz de celdas
    private final int filas;                  //
    private final int columnas;               //
    private Coordenada posicionMeta;          //
    private Coordenada posicionInicio;        //
    private final Random rand = new Random();

    // Constantes para la generación
    private static final int CANTIDAD_TRAMPAS_PORCENTAJE = 5; // 5% de celdas libres
    private static final int CANTIDAD_ENERGIA_PORCENTAJE = 3; // 3% de celdas libres

    public Laberinto(int filas, int columnas) { //
        // Aseguramos que las dimensiones sean impares para el algoritmo
        this.filas = (filas % 2 == 0) ? filas + 1 : filas;
        this.columnas = (columnas % 2 == 0) ? columnas + 1 : columnas;

        this.celdas = new Celda[this.filas][this.columnas];
        generarLaberinto(); //
    }

    /**
     * Método principal para generar el laberinto.
     * Utiliza un algoritmo de "Randomized DFS" para "cavar" caminos.
     * Luego, coloca los objetos especiales (Meta, Llave, Trampas, etc.).
     */
    private void generarLaberinto() {
        // 1. Inicializar todo el laberinto como MURO
        for (int i = 0; i < filas; i++) {
            for (int j = 0; j < columnas; j++) {
                celdas[i][j] = new Celda(TipoCelda.MURO);
            }
        }

        // 2. Usar Randomized DFS (Recursive Backtracker) para cavar caminos
        Stack<Coordenada> stack = new Stack<>();
        // Empezamos en una celda impar (ej. 1, 1)
        Coordenada inicial = new Coordenada(1, 1);
        celdas[1][1].setTipo(TipoCelda.CAMINO);
        stack.push(inicial);

        while (!stack.isEmpty()) {
            Coordenada actual = stack.peek();
            List<Coordenada> vecinos = obtenerVecinosDFS(actual);

            if (vecinos.isEmpty()) {
                // No hay vecinos válidos, retroceder (backtrack)
                stack.pop();
            } else {
                // Elegir un vecino al azar
                Coordenada vecino = vecinos.get(rand.nextInt(vecinos.size()));

                // Cavar el muro entre la celda actual y el vecino
                int muroEntreX = (actual.x() + vecino.x()) / 2;
                int muroEntreY = (actual.y() + vecino.y()) / 2;
                celdas[muroEntreX][muroEntreY].setTipo(TipoCelda.CAMINO);

                // Mover al vecino
                celdas[vecino.x()][vecino.y()].setTipo(TipoCelda.CAMINO);
                stack.push(vecino);
            }
        }

        // 3. Colocar objetos, inicio y meta
        colocarObjetosEspeciales();
    }

    /**
     * Método auxiliar para el DFS. Encuentra vecinos válidos (a 2 celdas de
     * distancia y que sean MURO).
     */
    private List<Coordenada> obtenerVecinosDFS(Coordenada c) {
        List<Coordenada> vecinos = new ArrayList<>();
        int[][] direcciones = {{0, 2}, {2, 0}, {0, -2}, {-2, 0}}; // N, S, E, O

        for (int[] dir : direcciones) {
            int nuevoX = c.x() + dir[0];
            int nuevoY = c.y() + dir[1];

            // Comprobar que esté dentro de los límites y sea un muro
            if (esPosicionValida(nuevoX, nuevoY) && celdas[nuevoX][nuevoY].getTipo() == TipoCelda.MURO) {
                vecinos.add(new Coordenada(nuevoX, nuevoY));
            }
        }
        return vecinos;
    }

    /**
     * Coloca los elementos interactivos (Inicio, Meta, Llave, Trampas, Energía)
     * en celdas de tipo CAMINO de forma aleatoria y sin solaparse.
     */
    private void colocarObjetosEspeciales() {
        // 1. Obtener todas las celdas libres (CAMINO)
        List<Coordenada> celdasLibres = new ArrayList<>();
        for (int i = 0; i < filas; i++) {
            for (int j = 0; j < columnas; j++) {
                if (celdas[i][j].getTipo() == TipoCelda.CAMINO) {
                    celdasLibres.add(new Coordenada(i, j));
                }
            }
        }

        // 2. Barajar la lista para obtener posiciones aleatorias únicas
        Collections.shuffle(celdasLibres);

        // 3. Colocar Posición Inicial
        // Usamos pop() para tomar un elemento y removerlo de la lista
        this.posicionInicio = celdasLibres.remove(celdasLibres.size() - 1);

        // 4. Colocar Meta
        this.posicionMeta = celdasLibres.remove(celdasLibres.size() - 1);
        celdas[posicionMeta.x()][posicionMeta.y()].setTipo(TipoCelda.META);

        // 5. Colocar UNA Llave
        Coordenada posLlave = celdasLibres.remove(celdasLibres.size() - 1);
        celdas[posLlave.x()][posLlave.y()].setTipo(TipoCelda.LLAVE);

        // 6. Colocar Trampas
        int numTrampas = (celdasLibres.size() * CANTIDAD_TRAMPAS_PORCENTAJE) / 100;
        for (int i = 0; i < numTrampas && !celdasLibres.isEmpty(); i++) {
            Coordenada posTrampa = celdasLibres.remove(celdasLibres.size() - 1);
            celdas[posTrampa.x()][posTrampa.y()].setTipo(TipoCelda.TRAMPA);
        }

        // 7. Colocar Energía
        int numEnergia = (celdasLibres.size() * CANTIDAD_ENERGIA_PORCENTAJE) / 100;
        for (int i = 0; i < numEnergia && !celdasLibres.isEmpty(); i++) {
            Coordenada posEnergia = celdasLibres.remove(celdasLibres.size() - 1);
            celdas[posEnergia.x()][posEnergia.y()].setTipo(TipoCelda.ENERGIA);
        }

    }

    /**
     * Devuelve la celda en la posición especificada.
     * @return Celda, o null si la posición está fuera de los límites.
     */
    public Celda getCelda(int fila, int col) { //
        if (esPosicionValida(fila, col)) {
            return celdas[fila][col];
        }
        return null; // O lanzar excepción
    }

    /**
     * Verifica si una coordenada (fila, col) está dentro de los
     * límites del laberinto.
     */
    public boolean esPosicionValida(int fila, int col) { //
        return fila >= 0 && fila < filas && col >= 0 && col < columnas;
    }

    public Coordenada getPosicionInicio() {
        return posicionInicio;
    }

    public Coordenada getPosicionMeta() {
        return posicionMeta;
    }

    public int getFilas() {
        return filas;
    }

    public int getColumnas() {
        return columnas;
    }
}
