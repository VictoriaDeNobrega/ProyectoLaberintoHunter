import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;

/**
 * Gestiona la carga, guardado y visualización de las estadísticas de las partidas.
 * Se coordina con GestorPersistencia para leer y escribir en archivos JSON.
 */
public class GestorEstadisticas {

    private List<Estadistica> estadisticas;         //
    private final GestorPersistencia persistencia;  //

    /**
     * Constructor que inicializa el gestor y carga las estadísticas existentes.
     * @param persistencia El gestor de persistencia para leer/escribir archivos.
     */
    public GestorEstadisticas(GestorPersistencia persistencia) { //
        this.persistencia = persistencia;
        cargarEstadisticas(); // Carga las estadísticas al iniciar
    }

    /**
     * Carga la lista de estadísticas desde el archivo JSON usando el gestor de persistencia.
     */
    private void cargarEstadisticas() { //
        this.estadisticas = persistencia.cargarEstadisticas();

        // Si el archivo no existía o estaba vacío, inicializa una lista nueva.
        if (this.estadisticas == null) {
            this.estadisticas = new ArrayList<>();
        }
    }

    /**
     * Añade una nueva estadística de partida a la lista y guarda la lista actualizada.
     * @param nuevaEstadistica El objeto Estadistica de la partida recién terminada.
     */
    public void guardarEstadisticaPartida(Estadistica nuevaEstadistica) { //
        if (nuevaEstadistica == null) {
            return;
        }

        // 1. Añade la nueva estadística a la lista en memoria
        this.estadisticas.add(nuevaEstadistica);

        // 2. Guarda la lista completa y actualizada en el archivo
        persistencia.guardarEstadisticas(this.estadisticas);
        System.out.println("¡Estadísticas de la partida guardadas!");
    }

    /**
     * Muestra por consola las estadísticas filtradas para un usuario específico.
     * @param correoUsuario El correo del usuario del cual se quieren ver las estadísticas.
     */
    public void mostrarEstadisticas(String correoUsuario) { //
        System.out.println("\n--- ESTADÍSTICAS PARA: " + correoUsuario + " ---");

        // 1. Filtrar la lista de estadísticas para el usuario actual
        List<Estadistica> statsUsuario = this.estadisticas.stream()
                .filter(e -> e.getCorreoUsuario().equals(correoUsuario))
                .sorted(Comparator.comparingLong(Estadistica::getTiempoTranscurridoMs)) // Opcional: ordenar
                .collect(Collectors.toList());

        // 2. Comprobar si se encontraron estadísticas
        if (statsUsuario.isEmpty()) {
            System.out.println("Aún no tienes partidas registradas.");
            System.out.println("-----------------------------------------");
            return;
        }

        // 3. Imprimir cada estadística encontrada
        int contadorPartidas = 1;
        for (Estadistica est : statsUsuario) {
            System.out.println("\n  --- Partida #" + contadorPartidas + " ---");
            System.out.println("  Resultado: " + (est.isGano() ? "🏆 ¡Victoria!" : "💀 Derrota"));

            // Formatear el tiempo de Milisegundos a Minutos:Segundos
            long millis = est.getTiempoTranscurridoMs();
            long minutos = (millis / (1000 * 60)) % 60;
            long segundos = (millis / 1000) % 60;
            System.out.printf("  Tiempo de Juego: %02d:%02d\n", minutos, segundos); //

            System.out.println("  Tamaño Laberinto: " + est.getFilasLaberinto() + "x" + est.getColumnasLaberinto());
            System.out.println("  Cristales Recolectados: " + est.getCristalesRecolectados()); //
            System.out.println("  Trampas Activadas: " + est.getTrampasActivadas()); //
            System.out.println("  Vida Restante: " + est.getVidaRestante() + "%%"); //

            contadorPartidas++;
        }
        System.out.println("-----------------------------------------");
    }
}