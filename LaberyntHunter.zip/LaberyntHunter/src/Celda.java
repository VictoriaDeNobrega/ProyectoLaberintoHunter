public class Celda {
    private TipoCelda tipo;
    private boolean fueVisitada;

    public Celda(TipoCelda tipo) {
        this.tipo = tipo;
        this.fueVisitada = false;
    }

    public TipoCelda getTipo() {
        return tipo;
    }

    public void setTipo(TipoCelda tipo) {
        this.tipo = tipo;
    }

    public boolean esTransitable() {
        return tipo.esTransitable();
    }

    public boolean fueVisitada() {
        return fueVisitada;
    }

    public void setFueVisitada(boolean fueVisitada) {
        this.fueVisitada = fueVisitada;
    }

    //
    public char getCaracterConsola(boolean esJugador) {
        if (esJugador) {
            // El requisito usa '@' para el jugador
            return '@';
        }
        return tipo.getCaracter();
    }
}
