import java.util.Scanner;
import java.util.regex.Pattern;

/**
 * Clase principal que gestiona la interfaz de usuario por consola.
 * Maneja los menús de autenticación y de juego.
 */
public class MenuPrincipal {
    private final GestorUsuario gestorUsuarios;       //
    private final GestorEstadisticas gestorEstadisticas; //
    private final Juego juego;                         //

    // Atributos de la clase
    private final Scanner scanner;                     //
    private Usuario usuarioActual;                     //

    // Patrón para validación simple de email
    private static final Pattern EMAIL_PATTERN = Pattern.compile(
            "^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\\.[a-zA-Z]{2,6}$"
    );

    /**
     * Constructor que inicializa el menú con sus gestores.
     * @param gestorUsuarios Gestor para la lógica de usuarios.
     * @param gestorEstadisticas Gestor para la lógica de estadísticas.
     * @param juego Motor principal del juego.
     */
    public MenuPrincipal(GestorUsuario gestorUsuarios, GestorEstadisticas gestorEstadisticas, Juego juego) { //
        this.gestorUsuarios = gestorUsuarios;
        this.gestorEstadisticas = gestorEstadisticas;
        this.juego = juego;
        this.scanner = new Scanner(System.in);
        this.usuarioActual = null;
    }

    /**
     * Inicia la aplicación y muestra el menú de autenticación.
     * Es el bucle principal de la aplicación.
     */
    public void iniciarAplicacion() { //
        System.out.println("¡Bienvenido a Maze Hunter!");

        // Bucle del menú de autenticación
        while (true) {
            mostrarMenuAutenticacion();
            String opcion = scanner.nextLine();

            switch (opcion) {
                case "1":
                    if (gestionarLogin()) {
                        // Si el login es exitoso, mostrar el menú de juego
                        mostrarMenuJuego();
                    }
                    break;
                case "2":
                    gestionarRegistro();
                    break;
                case "3":
                    gestionarRecuperarContrasena();
                    break;
                case "4":
                    System.out.println("Gracias por jugar. ¡Adiós!");
                    return; // Termina la aplicación
                default:
                    System.out.println("Opción no válida. Por favor, intente de nuevo.");
            }
        }
    }

    /**
     * Muestra las opciones del menú de autenticación.
     */
    private void mostrarMenuAutenticacion() { //
        System.out.println("\n--- MENÚ DE AUTENTICACIÓN ---");
        System.out.println("1. Iniciar Sesión"); //
        System.out.println("2. Registrarse"); //
        System.out.println("3. Recuperar Contraseña"); //
        System.out.println("4. Salir");
        System.out.print("Seleccione una opción: ");
    }

    /**
     * Gestiona el flujo de registro de un nuevo usuario.
     */
    private void gestionarRegistro() { //
        System.out.println("\n--- Registro de Nuevo Usuario ---");
        System.out.print("Correo electrónico: ");
        String correo = scanner.nextLine();

        // Validar formato de correo
        if (!EMAIL_PATTERN.matcher(correo).matches()) {
            System.out.println("Error: Formato de correo no válido.");
            return;
        }

        System.out.print("Contraseña: ");
        String contrasena = scanner.nextLine();

        // Validar contraseña
        if (!esContrasenaValida(contrasena)) {
            System.out.println("Error: La contraseña debe tener al menos 8 caracteres,");
            System.out.println("una mayúscula, una minúscula, un número y un carácter especial.");
            return;
        }

        System.out.print("Repetir Contraseña: ");
        String contrasenaRepetida = scanner.nextLine();
        // Se llama al gestor, que manejará la lógica de cifrado y guardado.
        boolean exito = gestorUsuarios.registrarUsuario(correo, contrasena, contrasenaRepetida);

        if (exito) {
            System.out.println("¡Registro exitoso!");
        } else {
            // El gestorUsuarios imprimirá el error específico
        }
    }

    /**
     * Validador de los requisitos de contraseña.
     */
    private boolean esContrasenaValida(String p) {
        return p.length() >= 8 &&
                p.matches(".*[A-Z].*") && // al menos una mayúscula
                p.matches(".*[a-z].*") && // al menos una minúscula
                p.matches(".*[0-9].*") && // al menos un número
                p.matches(".*[!@#$%^&*()_+\\-=\\[\\]{};':\"\\\\|,.<>\\/?].*"); // al menos un especial
    }

    /**
     * Gestiona el flujo de inicio de sesión.
     * @return true si el login fue exitoso, false en caso contrario.
     */
    private boolean gestionarLogin() { //
        System.out.println("\n--- Iniciar Sesión ---");
        System.out.print("Correo electrónico: ");
        String correo = scanner.nextLine();
        System.out.print("Contraseña: ");
        String contrasena = scanner.nextLine();

        this.usuarioActual = gestorUsuarios.autenticarUsuario(correo, contrasena);

        if (this.usuarioActual != null) {
            System.out.println("\n¡Bienvenido de nuevo, " + this.usuarioActual.getCorreo() + "!");
            return true;
        } else {
            System.out.println("Error: Correo o contraseña incorrectos."); //
            return false;
        }
    }

    /**
     * Gestiona el flujo de recuperación de contraseña.
     */
    private void gestionarRecuperarContrasena() { //
        System.out.println("\n--- Recuperar Contraseña ---");
        System.out.print("Ingrese su correo electrónico: ");
        String correo = scanner.nextLine();

        String contrasenaRecuperada = gestorUsuarios.recuperarContrasena(correo);
        System.out.println(contrasenaRecuperada);
    }

    /**
     * Muestra el menú principal del juego (después de autenticarse).
     */
    private void mostrarMenuJuego() { //
        // Bucle del menú de juego
        while (true) {
            System.out.println("\n--- MENÚ PRINCIPAL ---");
            System.out.println("Usuario: " + usuarioActual.getCorreo());
            System.out.println("1. Iniciar Partida Nueva"); //
            System.out.println("2. Cargar Partida Guardada"); //
            System.out.println("3. Ver Estadísticas"); //
            System.out.println("4. Cerrar Sesión");
            System.out.print("Seleccione una opción: ");

            String opcion = scanner.nextLine();

            switch (opcion) {
                case "1":
                    gestionarJuegoNueva();
                    break;
                case "2":
                    System.out.println("Cargando partida guardada...");
                    juego.cargarPartida(this.usuarioActual);
                    break;
                case "3":
                    gestorEstadisticas.mostrarEstadisticas(this.usuarioActual.getCorreo());
                    break;
                case "4":
                    System.out.println("Cerrando sesión...");
                    this.usuarioActual = null; // Cierra la sesión
                    return; // Vuelve al menú de autenticación
                default:
                    System.out.println("Opción no válida. Por favor, intente de nuevo.");
            }
        }
    }

    /**
     * Gestiona la creación de una nueva partida, pidiendo la dificultad.
     */
    private void gestionarJuegoNueva() { //
        int filas = 10, columnas = 10; // Default
        System.out.println("\n--- Nueva Partida ---");
        System.out.println("Seleccione la dificultad:");
        System.out.println("1. Fácil (10x10)");
        System.out.println("2. Normal (15x15)");
        System.out.println("3. Difícil (20x20)");
        System.out.print("Opción: ");

        String opcion = scanner.nextLine();

        //
        switch (opcion) {
            case "1":
                filas = 10; columnas = 10;
                break;
            case "2":
                filas = 15; columnas = 15;
                break;
            case "3":
                filas = 20; columnas = 20;
                break;
            default:
                System.out.println("Opción no válida, iniciando en modo Fácil (10x10).");
                filas = 10; columnas = 10;
        }

        System.out.println("Iniciando partida " + filas + "x" + columnas + "...");
        juego.iniciarPartidaNueva(this.usuarioActual, filas, columnas);
    }
}