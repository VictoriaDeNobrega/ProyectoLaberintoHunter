// Archivo: Main.java
public class Main {
    public static void main(String[] args) { //

        // 1. Inicializar componentes
        AlgoritmoCifrado cifrador = new CifradoAES();
        GestorPersistencia persistencia = new GestorPersistencia();
        GestorEstadisticas gestorEstadisticas = new GestorEstadisticas(persistencia);
        GestorUsuarios gestorUsuarios = new GestorUsuarios(persistencia, cifrador);
        Juego juego = new Juego(persistencia, gestorEstadisticas);

        // 2. Iniciar el menú principal
        MenuPrincipal menu = new MenuPrincipal(gestorUsuarios, gestorEstadisticas, juego); //

        menu.iniciarAplicacion(); //
    }
}