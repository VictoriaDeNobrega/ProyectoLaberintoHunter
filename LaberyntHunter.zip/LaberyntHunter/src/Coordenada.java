public record Coordenada(int x, int y) {
}
