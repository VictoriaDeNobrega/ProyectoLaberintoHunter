public class Estadistica {
    private final String correoUsuario;
    private final long tiempoTranscurridoMs;
    private final int filasLaberinto;
    private final int columnasLaberinto;
    private final int cristalesRecolectados;
    private final int trampasActivadas;
    private int vidaRestante = 0;
    private final boolean gano;

    /**
     * Constructor completo para crear un nuevo registro de estadística.
     *
     * @param correoUsuario         Correo del usuario que jugó.
     * @param tiempoTranscurridoMs  Tiempo total de juego en milisegundos.
     * @param filasLaberinto        Número de filas del laberinto.
     * @param columnasLaberinto     Número de columnas del laberinto.
     * @param cristalesRecolectados Total de cristales/energía obtenidos.
     * @param trampasActivadas      Total de trampas pisadas.
     * @param gano                  true si el jugador ganó la partida, false si perdió o abandonó.
     */
    public Estadistica(String correoUsuario, long tiempoTranscurridoMs, int filasLaberinto, int columnasLaberinto, int cristalesRecolectados, int trampasActivadas, boolean gano) {
        this.correoUsuario = correoUsuario;
        this.tiempoTranscurridoMs = tiempoTranscurridoMs;
        this.filasLaberinto = filasLaberinto;
        this.columnasLaberinto = columnasLaberinto;
        this.cristalesRecolectados = cristalesRecolectados;
        this.trampasActivadas = trampasActivadas;
        this.vidaRestante = vidaRestante;
        this.gano = gano;
    }

    public String getCorreoUsuario() {
        return correoUsuario;
    }

    public long getTiempoTranscurridoMs() {
        return tiempoTranscurridoMs;
    }

    public int getFilasLaberinto() {
        return filasLaberinto;
    }

    public int getColumnasLaberinto() {
        return columnasLaberinto;
    }

    public int getCristalesRecolectados() {
        return cristalesRecolectados;
    }

    public int getTrampasActivadas() {
        return trampasActivadas;
    }

    public int getVidaRestante() {
        return vidaRestante;
    }

    public boolean isGano() {
        return gano;
    }
}