public interface AlgoritmoCifrado { //
    String cifrar(String textoPlano);   //
    String descifrar(String textoCifrado); //
}
