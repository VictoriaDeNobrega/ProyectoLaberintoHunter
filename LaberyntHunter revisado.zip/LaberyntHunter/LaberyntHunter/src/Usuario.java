public class Usuario {

    // Atributos basados en el uso en GestorUsuarios y Estadistica
    private final String correo;
    private final String contrasenaCifrada;

    /**
     * Constructor para crear un nuevo usuario.
     * @param correo El correo electrónico del usuario (usado como ID).
     * @param contrasenaCifrada La contraseña ya procesada por un AlgoritmoCifrado.
     */
    public Usuario(String correo, String contrasenaCifrada) {
        this.correo = correo;
        this.contrasenaCifrada = contrasenaCifrada;
    }

    /**
     * Obtiene el correo electrónico del usuario.
     * @return El correo del usuario.
     */
    public String getCorreo() {
        return correo;
    }

    /**
     * Obtiene la contraseña en formato cifrado.
     * @return La contraseña cifrada.
     */
    public String getContrasenaCifrada() {
        return contrasenaCifrada;
    }

    /**
     * Compara una contraseña en texto plano con la versión cifrada almacenada.
     * Este método se infiere de la lógica de autenticación .
     *
     * @param contrasenaPlana La contraseña que el usuario ingresó.
     * @param cifrador El algoritmo de cifrado para descifrar la contraseña.
     * @return true si las contraseñas coinciden, false en caso contrario.
     */
    public boolean verificarContrasena(String contrasenaPlana, AlgoritmoCifrado cifrador) {
        try {
            // Descifra la contraseña almacenada
            String contrasenaDescifrada = cifrador.descifrar(this.contrasenaCifrada);
            // Compara la versión descifrada con la que ingresó el usuario
            return contrasenaDescifrada.equals(contrasenaPlana);
        } catch (Exception e) {
            // Manejar excepciones de descifrado (ej. clave incorrecta, padding)
            System.err.println("Error al verificar contraseña: " + e.getMessage());
            return false;
        }
    }

    @Override
    public String toString() {
        return "Usuario{" +
                "correo='" + correo + '\'' +
                '}';
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Usuario usuario = (Usuario) o;
        return correo.equals(usuario.correo);
    }

    @Override
    public int hashCode() {
        return correo.hashCode();
    }
}
