import java.util.Scanner;

public class Juego {
    private Laberinto laberinto;
    private Jugador jugador;
    private final GestorPersistencia gestorPersistencia;
    private final GestorEstadisticas gestorEstadisticas;
    private Usuario usuarioActual;
    private boolean enPartida;
    private long tiempoInicio;

    public Juego(GestorPersistencia gp, GestorEstadisticas ge) {
        this.gestorPersistencia = gp;
        this.gestorEstadisticas = ge;
        this.enPartida = false;
    }

    public void iniciarPartidaNueva(Usuario usuario, int filas, int columnas) {
        System.out.println("Creando laberinto... Espere un momento.");
        this.laberinto = new Laberinto(filas, columnas);
        this.jugador = new Jugador(laberinto.getPosicionInicio());
        this.usuarioActual = usuario;
        this.enPartida = true;
        this.tiempoInicio = System.currentTimeMillis();

        System.out.println("¡A Jugar! Usa W, A, S, D. Necesitas TODOS los cristales.");
        bucleDeJuego();
    }

    public void cargarPartida(Usuario usuario) {
        EstadoJuego estadoGuardado = gestorPersistencia.cargarPartidaGuardada(usuario);

        if (estadoGuardado != null) {
            this.laberinto = estadoGuardado.getLaberinto();
            this.jugador = estadoGuardado.getJugador();
            this.usuarioActual = usuario;
            this.enPartida = true;

            // Calculo el tiempo para que siga contando desde donde quedo
            long tiempoYaJugado = estadoGuardado.getTiempoTranscurridoParcialMs();
            this.tiempoInicio = System.currentTimeMillis() - tiempoYaJugado;

            System.out.println("Partida recuperada. ¡Suerte!");
            bucleDeJuego();
        } else {
            System.out.println("No encontre partidas guardadas para este usuario.");
        }
    }

    private void bucleDeJuego() {
        Scanner scanner = new Scanner(System.in);

        while (this.enPartida) {
            dibujarTablero();

            // HUD mejorado
            System.out.println("Vida: " + jugador.getVida() + "% | Llave: " + (jugador.tieneLlave() ? "SI" : "NO"));
            System.out.println("Cristales: " + jugador.getCristalesRecolectados() + "/" + laberinto.getTotalCristalesEnNivel()
                    + " | Puntos: " + jugador.getPuntuacion());

            System.out.print("Movimiento (WASD) o (Q)uit: ");

            String input = scanner.nextLine().toUpperCase();
            if (input.isEmpty()) continue;

            char mov = input.charAt(0);

            if (mov == 'Q') {
                System.out.println("Guardando partida... Nos vemos luego.");
                guardarPartidaActual(); // Aseguramos el guardado

                this.enPartida = false; // Apagamos el interruptor del bucle
                break; // Salimos del while
            }

            if ("WASD".indexOf(mov) != -1) {
                procesarMovimiento(mov);
                // Guardo automaticamente despues de mover
                guardarPartidaActual();
            } else {
                System.out.println("Tecla equivocada.");
            }

            if (jugador.getVida() <= 0) {
                dibujarTablero();
                terminarJuego(false, "Moriste en el intento.");
                break;
            }
        }
    }

    private void dibujarTablero() {
        // Truco sucio para limpiar consola
        System.out.print("\033[H\033[2J");
        System.out.flush();

        System.out.println("--- 🏺 MAZE HUNTER v2.0 🏺 ---");
        Coordenada posJugador = jugador.getPosicion();

        for (int i = 0; i < laberinto.getFilas(); i++) {
            for (int j = 0; j < laberinto.getColumnas(); j++) {
                if (i == posJugador.x() && j == posJugador.y()) {
                    System.out.print("@" + " ");
                } else {
                    Celda celda = laberinto.getCelda(i, j);
                    System.out.print(celda.getTipo().getCaracter() + " ");
                }
            }
            System.out.println();
        }
        System.out.println("---------------------------");
    }

    private void procesarMovimiento(char mov) {
        Coordenada posActual = jugador.getPosicion();
        int deltaX = 0, deltaY = 0;

        switch (mov) {
            case 'W': deltaX = -1; break;
            case 'A': deltaY = -1; break;
            case 'S': deltaX = 1;  break;
            case 'D': deltaY = 1;  break;
        }

        int nuevaX = posActual.x() + deltaX;
        int nuevaY = posActual.y() + deltaY;

        if (!laberinto.esPosicionValida(nuevaX, nuevaY)) return;

        Celda celdaDestino = laberinto.getCelda(nuevaX, nuevaY);

        if (!celdaDestino.esTransitable()) {
            System.out.println("Hay un muro ahi.");
            return;
        }

        jugador.mover(deltaX, deltaY);
        interactuarConCelda(celdaDestino);
    }

    private void interactuarConCelda(Celda celda) {
        TipoCelda tipo = celda.getTipo();

        if (celda.fueVisitada()) {
            if (tipo == TipoCelda.META) {
                verificarCondicionVictoria();
            }
            return;
        }

        switch (tipo) {
            case TRAMPA:
                int dano = 10;
                jugador.recibirDano(dano);
                jugador.activarTrampa();
                System.out.println("¡Trampa! -" + dano + " vida.");
                celda.setFueVisitada(true);
                break;

            case LLAVE:
                jugador.recolectarLlave();
                System.out.println("¡Tengo la llave!");
                celda.setTipo(TipoCelda.CAMINO);
                celda.setFueVisitada(true);
                break;

            case CRISTAL: // Nuevo caso para cristales
                jugador.recolectarCristal();
                System.out.println("¡Cristal obtenido! +100 puntos.");
                celda.setTipo(TipoCelda.CAMINO);
                celda.setFueVisitada(true);
                break;

            case VIDA_EXTRA:
                int cura = 20;
                jugador.curar(cura);
                System.out.println("¡Curacion! +" + cura + " vida.");
                celda.setTipo(TipoCelda.CAMINO);
                celda.setFueVisitada(true);
                break;

            case META:
                celda.setFueVisitada(true);
                verificarCondicionVictoria();
                break;

            default: break;
        }
    }

    private void verificarCondicionVictoria() {
        Coordenada pos = jugador.getPosicion();
        if (laberinto.getCelda(pos.x(), pos.y()).getTipo() != TipoCelda.META) {
            return;
        }

        // REQUISITO: Llave Y todos los cristales
        boolean tieneCristales = jugador.getCristalesRecolectados() >= laberinto.getTotalCristalesEnNivel();

        if (jugador.tieneLlave() && tieneCristales) {
            dibujarTablero();
            terminarJuego(true, "¡GANASTE! Escapaste con todo el botin.");
        } else {
            System.out.println("No puedes salir aun.");
            if (!jugador.tieneLlave()) System.out.println("- Te falta la llave.");
            if (!tieneCristales) System.out.println("- Te faltan cristales (" + jugador.getCristalesRecolectados() + "/" + laberinto.getTotalCristalesEnNivel() + ").");
        }
    }

    public void terminarJuego(boolean gano, String mensaje) {
        if (!this.enPartida) return;

        this.enPartida = false;
        long tiempoTranscurrido = System.currentTimeMillis() - this.tiempoInicio;

        System.out.println("\n" + mensaje);
        System.out.println("Puntuacion Final: " + jugador.getPuntuacion());

        // Guardo la estadistica nueva
        Estadistica est = new Estadistica(
                usuarioActual.getCorreo(),
                tiempoTranscurrido,
                laberinto.getFilas(),
                laberinto.getColumnas(),
                jugador.getCristalesRecolectados(),
                jugador.getTrampasActivadas(),
                jugador.getPuntuacion(), // Paso la puntuacion
                gano
        );
        gestorEstadisticas.guardarEstadisticaPartida(est);

        // Borro la partida guardada porque ya termino
        gestorPersistencia.guardarPartidaActual(null, usuarioActual);
    }

    public void guardarPartidaActual() {
        if (!this.enPartida) return;

        long tiempoTranscurridoParcial = System.currentTimeMillis() - this.tiempoInicio;

        EstadoJuego estadoActual = new EstadoJuego(
                this.laberinto,
                this.jugador,
                tiempoTranscurridoParcial
        );
        gestorPersistencia.guardarPartidaActual(estadoActual, this.usuarioActual);
    }
}