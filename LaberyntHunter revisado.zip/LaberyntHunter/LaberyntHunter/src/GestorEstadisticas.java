import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;

public class GestorEstadisticas {

    private List<Estadistica> estadisticas;
    private final GestorPersistencia persistencia;
    // Necesito el cifrador aqui para mostrar los nombres reales en la tabla
    private AlgoritmoCifrado cifrador;

    // Modifique el constructor para recibir el cifrador
    public GestorEstadisticas(GestorPersistencia persistencia, AlgoritmoCifrado cifrador) {
        this.persistencia = persistencia;
        this.cifrador = cifrador; // Me lo guardo
        cargarEstadisticas();
    }

    private void cargarEstadisticas() {
        this.estadisticas = persistencia.cargarEstadisticas();
        if (this.estadisticas == null) {
            this.estadisticas = new ArrayList<>();
        }
    }

    public void guardarEstadisticaPartida(Estadistica nuevaEstadistica) {
        if (nuevaEstadistica == null) return;
        this.estadisticas.add(nuevaEstadistica);
        persistencia.guardarEstadisticas(this.estadisticas);
    }

    public void mostrarEstadisticas(String correoUsuario) {
        // Aqui el 'correoUsuario' que llega ESTA ENCRIPTADO.
        // Lo descifro solo para ponerlo en el titulo del print.
        String nombreRealUsuario = cifrador.descifrar(correoUsuario);

        System.out.println("\n--- ESTADISTICAS DE: " + nombreRealUsuario + " ---");

        // Filtro usando el correo cifrado (porque en el JSON de estadisticas se guarda cifrado)
        List<Estadistica> statsUsuario = this.estadisticas.stream()
                .filter(e -> e.getCorreoUsuario().equals(correoUsuario))
                .sorted(Comparator.comparingLong(Estadistica::getTiempoTranscurridoMs))
                .collect(Collectors.toList());

        if (statsUsuario.isEmpty()) {
            System.out.println("No has jugado nada todavia.");
            return;
        }

        System.out.println("------------------------------------------------------------------------------------------");
        System.out.printf("| %-10s | %-8s | %-10s | %-10s | %-10s | %-10s |\n",
                "Resultado", "Puntos", "Tiempo", "Tamaño", "Cristales", "Trampas");
        System.out.println("------------------------------------------------------------------------------------------");

        for (Estadistica est : statsUsuario) {
            long millis = est.getTiempoTranscurridoMs();
            long minutos = (millis / (1000 * 60)) % 60;
            long segundos = (millis / 1000) % 60;
            String tiempoStr = String.format("%02d:%02d", minutos, segundos);
            String tamanoStr = est.getFilasLaberinto() + "x" + est.getColumnasLaberinto();

            System.out.printf("| %-10s | %-8d | %-10s | %-10s | %-10d | %-10d |\n",
                    (est.isGano() ? "GANO" : "PERDIO"),
                    est.getPuntuacion(),
                    tiempoStr,
                    tamanoStr,
                    est.getCristalesRecolectados(),
                    est.getTrampasActivadas()
            );
        }
        System.out.println("------------------------------------------------------------------------------------------");
    }
}