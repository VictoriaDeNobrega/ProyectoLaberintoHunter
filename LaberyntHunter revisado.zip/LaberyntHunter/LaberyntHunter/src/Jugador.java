public class Jugador {
    public static final int VIDA_MAXIMA = 100;
    private int vida;
    private boolean tieneLlave;
    private int posX;
    private int posY;
    private int trampasActivadas;
    private int cristalesRecolectados; // Ahora cuenta cristales, no energia
    private int puntuacion;            // Puntos acumulados

    public Jugador(Coordenada posicionInicial) {
        this.vida = VIDA_MAXIMA;
        this.tieneLlave = false;
        this.posX = posicionInicial.x();
        this.posY = posicionInicial.y();
        this.trampasActivadas = 0;
        this.cristalesRecolectados = 0;
        this.puntuacion = 0;
    }

    public void mover(int deltaX, int deltaY) {
        this.posX += deltaX;
        this.posY += deltaY;
    }

    public boolean recibirDano(int cantidad) {
        this.vida -= cantidad;
        if (this.vida <= 0) {
            this.vida = 0;
            return false; // murio
        }
        return true;
    }

    public void curar(int cantidad) {
        this.vida += cantidad;
        if (this.vida > VIDA_MAXIMA) {
            this.vida = VIDA_MAXIMA;
        }
    }

    public void recolectarLlave() {
        this.tieneLlave = true;
        this.puntuacion += 500; // La llave da bastantes puntos
    }

    public void recolectarCristal() {
        this.cristalesRecolectados++;
        this.puntuacion += 100; // Cada cristal suma 100 puntos
    }

    public void activarTrampa() {
        this.trampasActivadas++;
        this.puntuacion -= 50; // Las trampas restan puntos!
        if(this.puntuacion < 0) this.puntuacion = 0;
    }

    public Coordenada getPosicion() {
        return new Coordenada(posX, posY);
    }

    // Getters simples
    public int getVida() { return vida; }
    public boolean tieneLlave() { return tieneLlave; }
    public int getTrampasActivadas() { return trampasActivadas; }
    public int getCristalesRecolectados() { return cristalesRecolectados; }
    public int getPuntuacion() { return puntuacion; }
}