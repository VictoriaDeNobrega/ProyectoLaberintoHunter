public enum TipoCelda {
    MURO('#', false),
    CAMINO(' ', true), // Puse espacio vacio para que se vea mas limpio
    META('X', true),
    TRAMPA('T', true),
    LLAVE('K', true),
    CRISTAL('C', true), // Cambie ENERGIA por CRISTAL y le puse un icono cool
    VIDA_EXTRA('+', true),
    JUGADOR('@', true);

    private final char caracter;
    private final boolean esTransitable;

    TipoCelda(char caracter, boolean esTransitable) {
        this.caracter = caracter;
        this.esTransitable = esTransitable;
    }

    public char getCaracter() {
        return caracter;
    }

    public boolean esTransitable() {
        return esTransitable;
    }
}