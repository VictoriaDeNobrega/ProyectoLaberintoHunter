public class Main {
    public static void main(String[] args) {

        AlgoritmoCifrado cifrador = new CifradoAES();
        GestorPersistencia persistencia = new GestorPersistencia();

        // AHORA: Le paso el cifrador tambien a Estadisticas para que pueda descifrar nombres
        GestorEstadisticas gestorEstadisticas = new GestorEstadisticas(persistencia, cifrador);

        GestorUsuario gestorUsuarios = new GestorUsuario(persistencia, cifrador);
        Juego juego = new Juego(persistencia, gestorEstadisticas);

        MenuPrincipal menu = new MenuPrincipal(gestorUsuarios, gestorEstadisticas, juego);

        menu.iniciarAplicacion();
    }
}