import java.util.Map;
import java.util.HashMap;

public class GestorUsuario {
    private Map<String, Usuario> usuarios;
    private final GestorPersistencia persistencia;
    private final AlgoritmoCifrado cifrador;

    public GestorUsuario(GestorPersistencia p, AlgoritmoCifrado c) {
        this.persistencia = p;
        this.cifrador = c;
        this.usuarios = new HashMap<>();
        cargarUsuarios();
    }

    public void cargarUsuarios() {
        Map<String, Usuario> cargados = persistencia.cargarUsuarios();
        if (cargados != null) {
            this.usuarios = cargados;
        }
    }

    private void guardarUsuarios() {
        persistencia.guardarUsuarios(usuarios);
    }

    public boolean registrarUsuario(String correo, String contrasena, String contrasenaRepetida) {
        // Validaciones basicas...
        if (!contrasena.equals(contrasenaRepetida)) {
            System.out.println("Las contraseñas no son iguales.");
            return false;
        }

        // AQUI ESTA EL CAMBIO: Cifro el correo ANTES de verificar si existe
        String correoCifrado = cifrador.cifrar(correo);

        if (usuarios.containsKey(correoCifrado)) {
            System.out.println("Ese correo ya esta registrado (lo se porque el cifrado coincide).");
            return false;
        }

        String contrasenaCifrada = cifrador.cifrar(contrasena);

        // Creo el usuario con TODO cifrado (correo y pass)
        Usuario nuevoUsuario = new Usuario(correoCifrado, contrasenaCifrada);

        // Lo guardo en el mapa usando la llave cifrada
        usuarios.put(correoCifrado, nuevoUsuario);

        guardarUsuarios();
        System.out.println("Usuario registrado. Tus datos son secretos ahora.");
        return true;
    }

    public Usuario autenticarUsuario(String correo, String contrasena) {
        // Como el usuario escribe su correo normal, tengo que cifrarlo
        // para buscarlo en mi mapa de usuarios cifrados.
        String correoCifrado = cifrador.cifrar(correo);

        Usuario usuario = usuarios.get(correoCifrado);

        if (usuario != null) {
            if (usuario.verificarContrasena(contrasena, cifrador)) {
                return usuario;
            }
        }
        return null;
    }

    public String recuperarContrasena(String correo) {
        // Igual aqui, cifro para buscar
        String correoCifrado = cifrador.cifrar(correo);
        Usuario usuario = usuarios.get(correoCifrado);

        if (usuario != null) {
            return cifrador.descifrar(usuario.getContrasenaCifrada());
        }
        return "No existe ese correo.";
    }

    public String obtenerCorreoDescifrado(Usuario usuario) {
        if (usuario == null) return "Desconocido";
        // Uso el cifrador que ya tengo guardado aqui
        return cifrador.descifrar(usuario.getCorreo());
    }
}