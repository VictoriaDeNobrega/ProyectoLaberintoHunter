import java.util.List;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Random;
import java.util.Stack;

public class Laberinto {

    private final Celda[][] celdas;
    private final int filas;
    private final int columnas;
    private Coordenada posicionMeta;
    private Coordenada posicionInicio;
    private int totalCristalesEnNivel; // IMPORTANTE: Para saber cuantos hay que buscar
    private final transient Random rand = new Random();
    // -------------------

    // Porcentajes de cosas que aparecen
    private static final int CANTIDAD_TRAMPAS_PORCENTAJE = 5;
    private static final int CANTIDAD_CRISTALES_PORCENTAJE = 4; // Un 4% seran cristales

    public Laberinto(int filas, int columnas) {
        // Ajusto filas y columnas para que el algoritmo no se rompa (impares)
        this.filas = (filas % 2 == 0) ? filas + 1 : filas;
        this.columnas = (columnas % 2 == 0) ? columnas + 1 : columnas;
        this.totalCristalesEnNivel = 0;

        this.celdas = new Celda[this.filas][this.columnas];
        generarLaberinto();
    }

    private void generarLaberinto() {
        // Lleno todo de muros primero
        for (int i = 0; i < filas; i++) {
            for (int j = 0; j < columnas; j++) {
                celdas[i][j] = new Celda(TipoCelda.MURO);
            }
        }

        // Algoritmo DFS para hacer caminos (copiado de internet jeje)
        Stack<Coordenada> stack = new Stack<>();
        Coordenada inicial = new Coordenada(1, 1);
        celdas[1][1].setTipo(TipoCelda.CAMINO);
        stack.push(inicial);

        while (!stack.isEmpty()) {
            Coordenada actual = stack.peek();
            List<Coordenada> vecinos = obtenerVecinosDFS(actual);

            if (vecinos.isEmpty()) {
                stack.pop();
            } else {
                Coordenada vecino = vecinos.get(rand.nextInt(vecinos.size()));
                // Rompo el muro del medio
                int muroEntreX = (actual.x() + vecino.x()) / 2;
                int muroEntreY = (actual.y() + vecino.y()) / 2;
                celdas[muroEntreX][muroEntreY].setTipo(TipoCelda.CAMINO);
                celdas[vecino.x()][vecino.y()].setTipo(TipoCelda.CAMINO);
                stack.push(vecino);
            }
        }

        colocarObjetosEspeciales();
    }

    private List<Coordenada> obtenerVecinosDFS(Coordenada c) {
        List<Coordenada> vecinos = new ArrayList<>();
        int[][] direcciones = {{0, 2}, {2, 0}, {0, -2}, {-2, 0}};

        for (int[] dir : direcciones) {
            int nuevoX = c.x() + dir[0];
            int nuevoY = c.y() + dir[1];

            if (esPosicionValida(nuevoX, nuevoY) && celdas[nuevoX][nuevoY].getTipo() == TipoCelda.MURO) {
                vecinos.add(new Coordenada(nuevoX, nuevoY));
            }
        }
        return vecinos;
    }

    private void colocarObjetosEspeciales() {
        // Busco donde hay camino libre
        List<Coordenada> celdasLibres = new ArrayList<>();
        for (int i = 0; i < filas; i++) {
            for (int j = 0; j < columnas; j++) {
                if (celdas[i][j].getTipo() == TipoCelda.CAMINO) {
                    celdasLibres.add(new Coordenada(i, j));
                }
            }
        }

        Collections.shuffle(celdasLibres);

        // Pongo el inicio y la meta
        this.posicionInicio = celdasLibres.remove(celdasLibres.size() - 1);
        this.posicionMeta = celdasLibres.remove(celdasLibres.size() - 1);
        celdas[posicionMeta.x()][posicionMeta.y()].setTipo(TipoCelda.META);

        // Pongo la llave
        Coordenada posLlave = celdasLibres.remove(celdasLibres.size() - 1);
        celdas[posLlave.x()][posLlave.y()].setTipo(TipoCelda.LLAVE);

        // Pongo las trampas
        int numTrampas = (celdasLibres.size() * CANTIDAD_TRAMPAS_PORCENTAJE) / 100;
        for (int i = 0; i < numTrampas && !celdasLibres.isEmpty(); i++) {
            Coordenada posTrampa = celdasLibres.remove(celdasLibres.size() - 1);
            celdas[posTrampa.x()][posTrampa.y()].setTipo(TipoCelda.TRAMPA);
        }

        // Pongo los cristales
        int numCristales = (celdasLibres.size() * CANTIDAD_CRISTALES_PORCENTAJE) / 100;
        // Me aseguro que al menos haya 1 cristal siempre
        if (numCristales == 0) numCristales = 1;

        this.totalCristalesEnNivel = numCristales; // Guardo cuantos genere

        for (int i = 0; i < numCristales && !celdasLibres.isEmpty(); i++) {
            Coordenada posC = celdasLibres.remove(celdasLibres.size() - 1);
            celdas[posC.x()][posC.y()].setTipo(TipoCelda.CRISTAL);
        }
    }

    public Celda getCelda(int fila, int col) {
        if (esPosicionValida(fila, col)) {
            return celdas[fila][col];
        }
        return null;
    }

    public boolean esPosicionValida(int fila, int col) {
        return fila >= 0 && fila < filas && col >= 0 && col < columnas;
    }

    public Coordenada getPosicionInicio() { return posicionInicio; }
    public Coordenada getPosicionMeta() { return posicionMeta; }
    public int getFilas() { return filas; }
    public int getColumnas() { return columnas; }
    public int getTotalCristalesEnNivel() { return totalCristalesEnNivel; }
}