public class Estadistica {
    private final String correoUsuario;
    private final long tiempoTranscurridoMs;
    private final int filasLaberinto;
    private final int columnasLaberinto;
    private final int cristalesRecolectados;
    private final int trampasActivadas;
    private final int puntuacion; // Nuevo campo
    private final boolean gano;

    // Constructor actualizado
    public Estadistica(String correoUsuario, long tiempoTranscurridoMs, int filasLaberinto, int columnasLaberinto, int cristalesRecolectados, int trampasActivadas, int puntuacion, boolean gano) {
        this.correoUsuario = correoUsuario;
        this.tiempoTranscurridoMs = tiempoTranscurridoMs;
        this.filasLaberinto = filasLaberinto;
        this.columnasLaberinto = columnasLaberinto;
        this.cristalesRecolectados = cristalesRecolectados;
        this.trampasActivadas = trampasActivadas;
        this.puntuacion = puntuacion;
        this.gano = gano;
    }

    // Getters
    public String getCorreoUsuario() { return correoUsuario; }
    public long getTiempoTranscurridoMs() { return tiempoTranscurridoMs; }
    public int getFilasLaberinto() { return filasLaberinto; }
    public int getColumnasLaberinto() { return columnasLaberinto; }
    public int getCristalesRecolectados() { return cristalesRecolectados; }
    public int getTrampasActivadas() { return trampasActivadas; }
    public int getPuntuacion() { return puntuacion; }
    public boolean isGano() { return gano; }
}