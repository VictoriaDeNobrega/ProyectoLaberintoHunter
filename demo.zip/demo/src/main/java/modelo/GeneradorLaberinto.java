package modelo;

import modelo.dificultad.DificultadJuego;
import java.util.Random;

public class GeneradorLaberinto {
    private TipoCelda[][] matriz;
    private int filas;
    private int columnas;
    private Random random = new Random();

    public TipoCelda[][] generar(DificultadJuego dificultad) {
        // 1. Configurar tamaño desde la dificultad
        this.filas = dificultad.obtenerFilas();
        // Ajuste para asegurar que sean impares (necesario para el algoritmo de paredes)
        if (this.filas % 2 == 0) this.filas++;

        this.columnas = dificultad.obtenerColumnas();
        if (this.columnas % 2 == 0) this.columnas++;

        this.matriz = new TipoCelda[filas][columnas];

        // 2. Llenar todo de muros al principio
        for (int i = 0; i < filas; i++) {
            for (int j = 0; j < columnas; j++) {
                matriz[i][j] = TipoCelda.MURO;
            }
        }

        // 3. Crear los caminos usando recursividad (empieza en 1,1)
        abrirCamino(1, 1);

        // 4. Colocar Inicio y Salida obligatoria
        matriz[1][1] = TipoCelda.INICIO;
        colocarElementoAleatorio(TipoCelda.SALIDA, 1);
        colocarElementoAleatorio(TipoCelda.LLAVE, 1);

        // 5. Colocar items según lo que diga la dificultad
        colocarElementoAleatorio(TipoCelda.TRAMPA, dificultad.obtenerTrampas());
        colocarElementoAleatorio(TipoCelda.ENERGIA, dificultad.obtenerEnergia());
        colocarElementoAleatorio(TipoCelda.BOMBA, dificultad.obtenerBombas());

        // 6. Colocar Muros Rojos y Cristales (números fijos o calculados)
        colocarElementoAleatorio(TipoCelda.MURO_ROJO, 5);
        colocarElementoAleatorio(TipoCelda.CRISTAL, 10);

        return matriz;
    }

    // Algoritmo Recursive Backtracker (DFS) para garantizar solución
    private void abrirCamino(int f, int c) {
        matriz[f][c] = TipoCelda.CAMINO;

        // Direcciones: Arriba, Abajo, Izq, Der (saltando de 2 en 2)
        int[][] direcciones = {{-2, 0}, {2, 0}, {0, -2}, {0, 2}};
        mezclarDirecciones(direcciones);

        for (int[] dir : direcciones) {
            int nuevaFila = f + dir[0];
            int nuevaCol = c + dir[1];

            // Verificamos que no nos salgamos del borde y que sea muro
            if (nuevaFila > 0 && nuevaFila < filas - 1 && nuevaCol > 0 && nuevaCol < columnas - 1
                    && matriz[nuevaFila][nuevaCol] == TipoCelda.MURO) {

                // Rompemos el muro que está en medio
                matriz[f + dir[0] / 2][c + dir[1] / 2] = TipoCelda.CAMINO;

                // Seguimos avanzando recursivamente
                abrirCamino(nuevaFila, nuevaCol);
            }
        }
    }

    // Método auxiliar para poner cosas solo donde hay camino
    private void colocarElementoAleatorio(TipoCelda tipo, int cantidad) {
        int colocados = 0;
        while (colocados < cantidad) {
            int f = random.nextInt(filas);
            int c = random.nextInt(columnas);

            // Solo colocamos si es camino libre
            if (matriz[f][c] == TipoCelda.CAMINO) {
                matriz[f][c] = tipo;
                colocados++;
            }
        }
    }

    // Mezcla el orden de las direcciones para que el laberinto sea aleatorio
    private void mezclarDirecciones(int[][] array) {
        for (int i = array.length - 1; i > 0; i--) {
            int index = random.nextInt(i + 1);
            int[] a = array[index];
            array[index] = array[i];
            array[i] = a;
        }
    }
}