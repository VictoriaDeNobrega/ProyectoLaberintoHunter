package modelo.dificultad;

import java.util.concurrent.ThreadLocalRandom;

public class DificultadMedia implements DificultadJuego {

    private int filas;
    private int columnas;

    public DificultadMedia() {
        // Filas: (16, 26) según la tabla.
        // Pero las reglas de trampas llegan hasta 25.
        // Además, Difícil empieza en 26.
        // nextInt(16, 26) genera números del 16 al 25. (El 26 es exclusivo)
        this.filas = ThreadLocalRandom.current().nextInt(16, 26);

        // Columnas: (25, 35) -> Generamos del 25 al 34 (o 35 si queremos incluirlo).
        // Si seguimos la lógica de intervalos anterior, ponemos 36 para llegar a 35.
        this.columnas = ThreadLocalRandom.current().nextInt(25, 36);
    }

    @Override
    public int obtenerFilas() {
        return filas;
    }

    @Override
    public int obtenerColumnas() {
        return columnas;
    }

    @Override
    public int obtenerTrampas() {
        // Regla exacta:
        // 4 trampas si hay de 16 a 20 filas.
        // 5 trampas si hay de 21 a 25 filas.
        if (this.filas <= 20) {
            return 4;
        } else {
            return 5;
        }
    }

    @Override
    public int obtenerEnergia() {
        // Regla exacta:
        // 4 energía si hay de 16 a 20 filas.
        // 5 energía si hay de 21 a 25 filas.
        if (this.filas <= 20) {
            return 4;
        } else {
            return 5;
        }
    }

    @Override
    public int obtenerBombas() {
        return 15; // Valor fijo según tabla
    }

    @Override
    public double obtenerPorcentajePerdida() {
        return 0.35; // 35% fijo
    }

    @Override
    public String obtenerTema() {
        return "cueva"; // Nombre de la carpeta
    }
}