package modelo.dificultad;

import java.util.concurrent.ThreadLocalRandom;

public class DificultadAvanzada implements DificultadJuego {

    private int filas;
    private int columnas;

    public DificultadAvanzada() {
        // Rango filas: De 46 a 55
        // nextInt(46, 56) genera hasta el 55.
        this.filas = ThreadLocalRandom.current().nextInt(46, 56);

        // Rango columnas: De 66 a 75
        // nextInt(66, 76) genera hasta el 75.
        this.columnas = ThreadLocalRandom.current().nextInt(66, 76);
    }

    @Override
    public int obtenerFilas() {
        return filas;
    }

    @Override
    public int obtenerColumnas() {
        return columnas;
    }

    @Override
    public int obtenerTrampas() {
        return 24; // Valor fijo
    }

    @Override
    public int obtenerEnergia() {
        return 24; // Valor fijo
    }

    @Override
    public int obtenerBombas() {
        return 25; // Valor fijo
    }

    @Override
    public double obtenerPorcentajePerdida() {
        return 0.35; // 35%
    }

    @Override
    public String obtenerTema() {
        return "end"; // Nombre de la carpeta
    }
}