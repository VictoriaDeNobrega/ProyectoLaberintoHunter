package modelo.dificultad;

public interface DificultadJuego {
    int obtenerFilas();
    int obtenerColumnas();
    int obtenerTrampas();
    int obtenerEnergia();
    int obtenerBombas();
    double obtenerPorcentajePerdida();
    String obtenerTema();
}