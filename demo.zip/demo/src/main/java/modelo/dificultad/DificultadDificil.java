package modelo.dificultad;

import java.util.concurrent.ThreadLocalRandom;

public class DificultadDificil implements DificultadJuego {

    private int filas;
    private int columnas;

    public DificultadDificil() {
        // Rango de filas: Desde 26 hasta 45
        // nextInt(origin, bound) -> El bound es exclusivo, así que ponemos 46
        this.filas = ThreadLocalRandom.current().nextInt(26, 46);

        // Rango de columnas: Desde 36 hasta 65
        this.columnas = ThreadLocalRandom.current().nextInt(36, 66);
    }

    @Override
    public int obtenerFilas() {
        return filas;
    }

    @Override
    public int obtenerColumnas() {
        return columnas;
    }

    @Override
    public int obtenerTrampas() {
        // Ahora sí la lógica calza perfecto con el rango de filas (26 a 45)

        if (this.filas <= 30) {
            // Regla: 26 a 30 filas
            return 6;
        } else if (this.filas <= 40) {
            // Regla: 31 a 40 filas
            return 12;
        } else {
            // Regla: 41 a 45 filas
            return 18;
        }
    }

    @Override
    public int obtenerEnergia() {
        // Misma distribución que las trampas
        if (this.filas <= 30) {
            return 6;
        } else if (this.filas <= 40) {
            return 12;
        } else {
            return 18;
        }
    }

    @Override
    public int obtenerBombas() {
        return 20;
    }

    @Override
    public double obtenerPorcentajePerdida() {
        return 0.35;
    }

    @Override
    public String obtenerTema() {
        return "nether"; // Nombre de la carpeta
    }
}