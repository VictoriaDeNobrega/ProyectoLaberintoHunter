package modelo.dificultad;

import java.util.concurrent.ThreadLocalRandom;

public class DificultadFacil implements DificultadJuego {

    private int filas;
    private int columnas;

    public DificultadFacil() {
        // AJUSTE: Aunque la columna tamaño dice (5,10), la columna trampas
        // menciona reglas para "11 a 15 filas". Por eso generamos entre 5 y 15.
        // El 16 es exclusivo, así que generará hasta el 15.
        this.filas = ThreadLocalRandom.current().nextInt(5, 16);

        // Columnas entre 15 y 25
        this.columnas = ThreadLocalRandom.current().nextInt(15, 26);
    }

    @Override
    public int obtenerFilas() {
        return filas;
    }

    @Override
    public int obtenerColumnas() {
        return columnas;
    }

    @Override
    public int obtenerTrampas() {
        // Regla: 2 trampas de 5-10 filas, 3 trampas de 11-15 filas
        if (this.filas <= 10) {
            return 2;
        } else {
            return 3;
        }
    }

    @Override
    public int obtenerEnergia() {
        // Regla: 2 de energía de 5-10 filas, 3 de energía de 11-15 filas
        if (this.filas <= 10) {
            return 2;
        } else {
            return 3;
        }
    }

    @Override
    public int obtenerBombas() {
        return 5;
    }

    @Override
    public double obtenerPorcentajePerdida() {
        return 0.35; // 35%
    }

    @Override
    public String obtenerTema() {
        return "bosque"; // Nombre de la carpeta
    }
}