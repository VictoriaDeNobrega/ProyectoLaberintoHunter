package modelo;

public enum TipoCelda {
    MURO("🧱"),
    CAMINO("  "),
    INICIO("SP"),
    SALIDA("🚪"),
    MURO_ROJO("🟥"),
    CRISTAL("💎"),
    BOMBA("💣"),
    TRAMPA("💀"),
    LLAVE("🗝"),
    LLAVE_EXPLOSIVA("🔑"),
    ENERGIA("⚡");

    private final String simbolo;

    TipoCelda(String simbolo) {
        this.simbolo = simbolo;
    }

    @Override
    public String toString() {
        return simbolo;
    }
}