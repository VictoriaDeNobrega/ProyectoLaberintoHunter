package principal;

import modelo.TipoCelda;
import modelo.GeneradorLaberinto;
import modelo.dificultad.DificultadFacil;

public class MainPrueba {
    public static void main(String[] args) {
        GeneradorLaberinto generador = new GeneradorLaberinto();

        System.out.println("--- Generando laberinto Dificultad FÁCIL ---");
        // Usamos la estrategia Fácil
        TipoCelda[][] laberinto = generador.generar(new DificultadFacil());

        // Imprimir en consola para ver cómo quedó
        for (TipoCelda[] fila : laberinto) {
            for (TipoCelda celda : fila) {
                System.out.print(celda.toString() + " ");
            }
            System.out.println();
        }
    }
}